# TaskMate - Student Task Manager

TaskMate is an Android application built with Kotlin, Jetpack Compose, and Room.

## Member 4 contribution: Task completion and filtering

- Displays tasks stored in the Room database.
- Provides a checkbox to mark each task as completed or pending.
- Saves status changes through `TaskDao.updateTaskStatus()`.
- Provides All, Pending, and Completed filters.
- Updates the task list and task counts automatically from the Room `Flow`.
- Shows an appropriate empty-state message when a selected filter has no tasks.

The task list is populated by the task-creation feature. If the database has no tasks yet, the screen displays an empty-state message until a task is added.

## Run the project

1. Extract the ZIP.
2. Open the extracted project folder in Android Studio (the folder containing `settings.gradle.kts`).
3. Allow Gradle Sync to finish.
4. Select an emulator or connected Android device and press Run.

Use JDK 17 or newer in Android Studio's Gradle settings. The project uses the Gradle wrapper included in the ZIP.
